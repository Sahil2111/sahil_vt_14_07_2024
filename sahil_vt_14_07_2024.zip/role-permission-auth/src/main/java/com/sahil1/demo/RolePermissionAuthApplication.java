package com.sahil1.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RolePermissionAuthApplication {
    public static void main(String[] args) {
        SpringApplication.run(RolePermissionAuthApplication.class, args);
    }
}


package com.sahil1.demo.enums;

public enum PermissionsEnum {
    AllowRead,
    AllowWrite,
    AllowUpdate
}


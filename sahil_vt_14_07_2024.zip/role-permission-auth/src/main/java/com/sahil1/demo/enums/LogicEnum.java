package com.sahil1.demo.enums;

public enum LogicEnum {
    All,
    Any
}

